OpenStreetMap contributors, ODbL 1.0. https://www.openstreetmap.org/copyright
Database licence: https://opendatacommons.org/licenses/odbl/1-0/
Corresponding source extract: https://download.geofabrik.de/europe/latvia-261031.osm.pbf
Source SHA256: d23856abae8a3b4abc616deae0d2b4d23e6ea4d5906c6a14486deaa5eb900811
Source: dated Geofabrik extract, footprint independently bounds availability. BRouter MIT. Noto Sans SIL OFL 1.1 where included (existing bundled glyphs).
OSM-only map: no external ocean/terrain shapefiles, elevation or verified conditional-access processing. Mapped roads are not proof of legal access or cycling safety. Native graph files cannot be cropped.
