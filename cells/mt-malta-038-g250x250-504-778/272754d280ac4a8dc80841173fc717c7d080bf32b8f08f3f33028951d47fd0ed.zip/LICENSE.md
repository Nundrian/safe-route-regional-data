OpenStreetMap contributors, ODbL 1.0. https://www.openstreetmap.org/copyright
Database licence: https://opendatacommons.org/licenses/odbl/1-0/
Corresponding source extract: https://download.geofabrik.de/europe/malta-261031.osm.pbf
Source SHA256: 092b5a1f845acf305fe79c9cbe13e08e4a0cea899a5d9b852e75a3e9b9cb53fe
Source: dated Geofabrik extract, footprint independently bounds availability. BRouter MIT. Noto Sans SIL OFL 1.1 where included (existing bundled glyphs).
OSM-only map: no external ocean/terrain shapefiles, elevation or verified conditional-access processing. Mapped roads are not proof of legal access or cycling safety. Native graph files cannot be cropped.
