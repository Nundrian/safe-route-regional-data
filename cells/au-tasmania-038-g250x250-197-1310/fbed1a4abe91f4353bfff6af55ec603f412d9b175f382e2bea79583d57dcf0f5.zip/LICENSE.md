OpenStreetMap contributors, ODbL 1.0. https://www.openstreetmap.org/copyright
Database licence: https://opendatacommons.org/licenses/odbl/1-0/
Corresponding source extract: https://download.geofabrik.de/australia-oceania/australia/tasmania-261030.osm.pbf
Source SHA256: 3e44d2fb87adba99ec75d85517ce23e71217701fba529c32dad480fdfd17410a
Source: dated Geofabrik extract, footprint independently bounds availability. BRouter MIT. Noto Sans SIL OFL 1.1 where included (existing bundled glyphs).
OSM-only map: no external ocean/terrain shapefiles, elevation or verified conditional-access processing. Mapped roads are not proof of legal access or cycling safety. Native graph files cannot be cropped.
