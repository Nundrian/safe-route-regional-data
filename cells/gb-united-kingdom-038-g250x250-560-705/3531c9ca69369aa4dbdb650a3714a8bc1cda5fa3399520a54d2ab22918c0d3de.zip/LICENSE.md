OpenStreetMap contributors, ODbL 1.0. https://www.openstreetmap.org/copyright
Database licence: https://opendatacommons.org/licenses/odbl/1-0/
Corresponding source extract: https://download.geofabrik.de/europe/united-kingdom-261030.osm.pbf
Source SHA256: ce7bbc7fb2b3b69025485ecd3772212c79d09f849938a907aff0c50278fbc0f8
Source: dated Geofabrik extract, footprint independently bounds availability. BRouter MIT. Noto Sans SIL OFL 1.1 where included (existing bundled glyphs).
OSM-only map: no external ocean/terrain shapefiles, elevation or verified conditional-access processing. Mapped roads are not proof of legal access or cycling safety. Native graph files cannot be cropped.
